---
  title: '{{ replace .File.ContentBaseName "-" " " | title }}'
  date: {{ .Date }}
  image: 'index.png'
  tags: ['']
  draft: true
---
