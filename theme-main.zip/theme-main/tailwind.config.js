/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./layouts/**/*.html'],
  plugins: [],
  darkMode: 'class',
};
